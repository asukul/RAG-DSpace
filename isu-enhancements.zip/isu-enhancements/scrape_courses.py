"""
ISU Course Catalog Scraper

Scrapes course information from:
1. https://catalog.iastate.edu/azcourses/com_s/
2. https://www.cs.iastate.edu/courses
3. Faculty pages for teaching assignments

Usage:
    python scrape_courses.py --output ./data/courses.json
"""

import asyncio
import httpx
import json
import re
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime, timezone
import logging
from bs4 import BeautifulSoup

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ISUCourseScraper:
    """Scrapes ISU CS course information."""
    
    def __init__(self):
        self.timeout = httpx.Timeout(30.0)
        self.courses = []
        self.faculty_courses = {}  # faculty_id -> [courses]
    
    async def scrape_catalog_courses(self) -> List[Dict]:
        """Scrape courses from ISU catalog."""
        logger.info("Scraping ISU course catalog...")
        
        url = "https://catalog.iastate.edu/azcourses/com_s/"
        courses = []
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url)
                
                if response.status_code != 200:
                    logger.error(f"Failed to fetch catalog: {response.status_code}")
                    return courses
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Find course blocks
                course_blocks = soup.find_all('div', class_='courseblock')
                
                for block in course_blocks:
                    try:
                        # Get course title (e.g., "COM S 101. Orientation to Computer Science.")
                        title_elem = block.find('p', class_='courseblocktitle')
                        if not title_elem:
                            continue
                        
                        title_text = title_elem.get_text(strip=True)
                        
                        # Parse course number and name
                        match = re.match(r'COM S (\d+[A-Z]?)\.\s*(.+?)\.?\s*(?:Cr\.|$)', title_text)
                        if match:
                            course_num = match.group(1)
                            course_name = match.group(2).strip()
                        else:
                            # Try alternate pattern
                            parts = title_text.split('.')
                            if len(parts) >= 2:
                                course_num = parts[0].replace('COM S', '').strip()
                                course_name = parts[1].strip()
                            else:
                                continue
                        
                        # Get credits
                        credits = ""
                        credit_match = re.search(r'Cr\.\s*([\d\-]+)', title_text)
                        if credit_match:
                            credits = credit_match.group(1)
                        
                        # Get description
                        desc_elem = block.find('p', class_='courseblockdesc')
                        description = desc_elem.get_text(strip=True) if desc_elem else ""
                        
                        # Get prerequisites
                        prereq = ""
                        prereq_match = re.search(r'Prereq:\s*([^\.]+)', description)
                        if prereq_match:
                            prereq = prereq_match.group(1).strip()
                        
                        # Determine level/category
                        num = int(re.match(r'\d+', course_num).group())
                        if num < 200:
                            level = "Introductory"
                        elif num < 300:
                            level = "Sophomore"
                        elif num < 400:
                            level = "Junior"
                        elif num < 500:
                            level = "Senior"
                        else:
                            level = "Graduate"
                        
                        # Categorize by topic based on name/description
                        topics = self._categorize_course(course_name, description)
                        
                        course = {
                            "id": f"com-s-{course_num.lower()}",
                            "number": f"COM S {course_num}",
                            "name": course_name,
                            "credits": credits,
                            "description": description[:500] if description else "",
                            "prerequisites": prereq,
                            "level": level,
                            "topics": topics,
                            "url": url
                        }
                        
                        courses.append(course)
                        
                    except Exception as e:
                        logger.warning(f"Error parsing course block: {e}")
                        continue
                
                logger.info(f"Found {len(courses)} courses from catalog")
                
        except Exception as e:
            logger.error(f"Catalog scrape error: {e}")
        
        return courses
    
    async def scrape_cs_dept_courses(self) -> List[Dict]:
        """Scrape additional course info from CS department website."""
        logger.info("Scraping CS department courses page...")
        
        url = "https://www.cs.iastate.edu/courses"
        courses = []
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url)
                
                if response.status_code != 200:
                    logger.warning(f"CS dept courses page: {response.status_code}")
                    return courses
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Look for course listings
                # The structure varies, so we try multiple selectors
                course_items = soup.find_all(['div', 'li', 'tr'], class_=re.compile(r'course|view-row'))
                
                for item in course_items:
                    text = item.get_text(strip=True)
                    
                    # Try to extract course info
                    match = re.search(r'(COM S \d+[A-Z]?)[:\s]+(.+)', text)
                    if match:
                        course_num = match.group(1)
                        course_name = match.group(2)[:100]
                        
                        courses.append({
                            "number": course_num,
                            "name": course_name,
                            "source": "cs_dept"
                        })
                
                logger.info(f"Found {len(courses)} from CS dept page")
                
        except Exception as e:
            logger.error(f"CS dept scrape error: {e}")
        
        return courses
    
    async def scrape_faculty_teaching(self, faculty_url: str, faculty_id: str) -> List[str]:
        """Scrape courses taught by a faculty member from their profile page."""
        courses = []
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                response = await client.get(faculty_url)
                
                if response.status_code != 200:
                    return courses
                
                soup = BeautifulSoup(response.text, 'html.parser')
                text = soup.get_text()
                
                # Look for course numbers in the page
                course_matches = re.findall(r'COM\s*S\s*(\d{3}[A-Z]?)', text, re.IGNORECASE)
                
                # Also look for "Courses Taught" section
                teaching_section = soup.find(string=re.compile(r'Courses?\s+Taught|Teaching', re.IGNORECASE))
                if teaching_section:
                    parent = teaching_section.find_parent(['div', 'section', 'p'])
                    if parent:
                        section_text = parent.get_text()
                        more_courses = re.findall(r'COM\s*S\s*(\d{3}[A-Z]?)', section_text, re.IGNORECASE)
                        course_matches.extend(more_courses)
                
                # Deduplicate and format
                seen = set()
                for num in course_matches:
                    formatted = f"COM S {num}"
                    if formatted not in seen:
                        seen.add(formatted)
                        courses.append(formatted)
                
        except Exception as e:
            logger.warning(f"Faculty teaching scrape error for {faculty_id}: {e}")
        
        return courses
    
    def _categorize_course(self, name: str, description: str) -> List[str]:
        """Categorize course by topic based on name and description."""
        topics = []
        combined = (name + " " + description).lower()
        
        topic_keywords = {
            "AI and Machine Learning": ["machine learning", "artificial intelligence", "neural", "deep learning", "ai"],
            "Software Engineering": ["software engineering", "software development", "testing", "agile", "design patterns"],
            "Systems and Networking": ["operating system", "network", "distributed", "parallel", "cloud", "database"],
            "Security": ["security", "cryptography", "cyber", "privacy"],
            "Theory": ["algorithm", "complexity", "computation", "automata", "theory"],
            "Programming Languages": ["programming language", "compiler", "interpreter", "functional", "type system"],
            "Data Science": ["data science", "data mining", "big data", "analytics", "visualization"],
            "Computer Vision": ["computer vision", "image processing", "graphics", "visualization"],
            "Human-Computer Interaction": ["human-computer", "hci", "user interface", "ux", "interaction"],
            "Bioinformatics": ["bioinformatics", "computational biology", "genomics"],
            "Robotics": ["robotics", "robot", "autonomous", "embedded"],
        }
        
        for topic, keywords in topic_keywords.items():
            if any(kw in combined for kw in keywords):
                topics.append(topic)
        
        if not topics:
            topics.append("Fundamentals")
        
        return topics
    
    async def scrape_all(self, faculty_list: List[Dict] = None) -> Dict:
        """Scrape all course data."""
        
        # Scrape catalog
        catalog_courses = await self.scrape_catalog_courses()
        
        # Scrape CS dept page
        dept_courses = await self.scrape_cs_dept_courses()
        
        # Merge courses
        course_dict = {}
        for course in catalog_courses:
            course_dict[course["number"]] = course
        
        # Add any additional from dept page
        for course in dept_courses:
            if course["number"] not in course_dict:
                course_dict[course["number"]] = {
                    "id": course["number"].lower().replace(" ", "-"),
                    "number": course["number"],
                    "name": course["name"],
                    "level": "Unknown",
                    "topics": [],
                    "source": "cs_dept"
                }
        
        self.courses = list(course_dict.values())
        
        # Scrape faculty teaching assignments
        if faculty_list:
            logger.info(f"Scraping teaching info for {len(faculty_list)} faculty...")
            
            for faculty in faculty_list:
                faculty_id = faculty.get("id", "")
                profile_url = faculty.get("profile_url", "")
                
                if profile_url:
                    courses_taught = await self.scrape_faculty_teaching(profile_url, faculty_id)
                    self.faculty_courses[faculty_id] = courses_taught
                    
                    if courses_taught:
                        logger.info(f"  {faculty.get('name', faculty_id)}: {len(courses_taught)} courses")
                    
                    await asyncio.sleep(0.3)  # Rate limiting
        
        return {
            "courses": self.courses,
            "faculty_courses": self.faculty_courses,
            "scraped_at": datetime.now(timezone.utc).isoformat(),
            "total_courses": len(self.courses)
        }
    
    def save(self, output_path: str):
        """Save scraped data to JSON."""
        data = {
            "courses": self.courses,
            "faculty_courses": self.faculty_courses,
            "scraped_at": datetime.now(timezone.utc).isoformat()
        }
        
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Saved {len(self.courses)} courses to {output_path}")


# Pre-defined course data (fallback if scraping fails)
KNOWN_COURSES = [
    {"number": "COM S 101", "name": "Orientation to Computer Science", "level": "Introductory", "topics": ["Fundamentals"]},
    {"number": "COM S 107", "name": "Introduction to Web Development", "level": "Introductory", "topics": ["Software Engineering"]},
    {"number": "COM S 127", "name": "Introduction to Computer Programming", "level": "Introductory", "topics": ["Fundamentals"]},
    {"number": "COM S 203", "name": "Computer Architecture", "level": "Sophomore", "topics": ["Systems and Networking"]},
    {"number": "COM S 227", "name": "Object-oriented Programming", "level": "Sophomore", "topics": ["Software Engineering"]},
    {"number": "COM S 228", "name": "Introduction to Data Structures", "level": "Sophomore", "topics": ["Fundamentals"]},
    {"number": "COM S 230", "name": "Discrete Computational Structures", "level": "Sophomore", "topics": ["Theory"]},
    {"number": "COM S 252", "name": "Linux Operating System Essentials", "level": "Sophomore", "topics": ["Systems and Networking"]},
    {"number": "COM S 309", "name": "Software Development Practices", "level": "Junior", "topics": ["Software Engineering"]},
    {"number": "COM S 311", "name": "Introduction to the Design and Analysis of Algorithms", "level": "Junior", "topics": ["Theory"]},
    {"number": "COM S 319", "name": "Software Construction and User Interfaces", "level": "Junior", "topics": ["Software Engineering", "Human-Computer Interaction"]},
    {"number": "COM S 321", "name": "Introduction to Computer Architecture and Machine-Level Programming", "level": "Junior", "topics": ["Systems and Networking"]},
    {"number": "COM S 327", "name": "Advanced Programming Techniques", "level": "Junior", "topics": ["Software Engineering"]},
    {"number": "COM S 331", "name": "Theory of Computing", "level": "Junior", "topics": ["Theory"]},
    {"number": "COM S 336", "name": "Introduction to Computer Graphics", "level": "Junior", "topics": ["Computer Vision"]},
    {"number": "COM S 342", "name": "Principles of Programming Languages", "level": "Junior", "topics": ["Programming Languages"]},
    {"number": "COM S 352", "name": "Introduction to Operating Systems", "level": "Junior", "topics": ["Systems and Networking"]},
    {"number": "COM S 362", "name": "Object-Oriented Analysis and Design", "level": "Junior", "topics": ["Software Engineering"]},
    {"number": "COM S 363", "name": "Introduction to Database Management Systems", "level": "Junior", "topics": ["Systems and Networking", "Data Science"]},
    {"number": "COM S 402", "name": "Computer Science Senior Project", "level": "Senior", "topics": ["Software Engineering"]},
    {"number": "COM S 409", "name": "Software Requirements Engineering", "level": "Senior", "topics": ["Software Engineering"]},
    {"number": "COM S 417", "name": "Software Testing", "level": "Senior", "topics": ["Software Engineering"]},
    {"number": "COM S 418", "name": "Introduction to Computational Geometry", "level": "Senior", "topics": ["Theory", "Computer Vision"]},
    {"number": "COM S 421", "name": "Logic for Mathematics and Computer Science", "level": "Senior", "topics": ["Theory"]},
    {"number": "COM S 425", "name": "Introduction to High Performance Computing", "level": "Senior", "topics": ["Systems and Networking"]},
    {"number": "COM S 430", "name": "Information Retrieval", "level": "Senior", "topics": ["Data Science", "AI and Machine Learning"]},
    {"number": "COM S 435", "name": "Introduction to Algorithms in Computational Biology", "level": "Senior", "topics": ["Bioinformatics"]},
    {"number": "COM S 440", "name": "Principles and Practice of Compiling", "level": "Senior", "topics": ["Programming Languages"]},
    {"number": "COM S 461", "name": "Principles and Internals of Database Systems", "level": "Senior", "topics": ["Systems and Networking"]},
    {"number": "COM S 472", "name": "Principles of Artificial Intelligence", "level": "Senior", "topics": ["AI and Machine Learning"]},
    {"number": "COM S 474", "name": "Introduction to Machine Learning", "level": "Senior", "topics": ["AI and Machine Learning"]},
    {"number": "COM S 477", "name": "Problem Solving Techniques for Applied Computer Science", "level": "Senior", "topics": ["Theory"]},
    {"number": "COM S 481", "name": "Computer Security", "level": "Senior", "topics": ["Security"]},
    {"number": "COM S 486", "name": "Fundamental Concepts in Computer Networking", "level": "Senior", "topics": ["Systems and Networking"]},
    {"number": "COM S 487", "name": "Network Programming, Applications, and Research Issues", "level": "Senior", "topics": ["Systems and Networking"]},
    {"number": "COM S 511", "name": "Design and Analysis of Algorithms", "level": "Graduate", "topics": ["Theory"]},
    {"number": "COM S 512", "name": "Formal Methods in Software Engineering", "level": "Graduate", "topics": ["Software Engineering", "Theory"]},
    {"number": "COM S 531", "name": "Theory of Computation", "level": "Graduate", "topics": ["Theory"]},
    {"number": "COM S 572", "name": "Principles of Artificial Intelligence", "level": "Graduate", "topics": ["AI and Machine Learning"]},
    {"number": "COM S 573", "name": "Machine Learning", "level": "Graduate", "topics": ["AI and Machine Learning"]},
    {"number": "COM S 574", "name": "Introduction to Machine Learning", "level": "Graduate", "topics": ["AI and Machine Learning"]},
    {"number": "COM S 575", "name": "Computational Perception", "level": "Graduate", "topics": ["Computer Vision", "AI and Machine Learning"]},
    {"number": "COM S 576", "name": "Introduction to Natural Language Processing", "level": "Graduate", "topics": ["AI and Machine Learning"]},
    {"number": "COM S 577", "name": "Computer Vision", "level": "Graduate", "topics": ["Computer Vision"]},
    {"number": "COM S 579", "name": "Introduction to Deep Learning", "level": "Graduate", "topics": ["AI and Machine Learning"]},
    {"number": "COM S 583", "name": "Reconfigurable Computing", "level": "Graduate", "topics": ["Systems and Networking"]},
    {"number": "COM S 587", "name": "Software Architecture", "level": "Graduate", "topics": ["Software Engineering"]},
]

# Known faculty teaching assignments (from CS website)
KNOWN_FACULTY_COURSES = {
    "adisak-sukul": ["COM S 227", "COM S 228", "COM S 309", "COM S 319", "COM S 363", "COM S 474", "COM S 579"],
    "susan-chang": ["COM S 227", "COM S 228", "COM S 252"],
    "simanta-mitra": ["COM S 309", "COM S 319", "COM S 362", "COM S 402"],
    "matthew-tancreti": ["COM S 321", "COM S 352"],
    "georgi-batinov": ["COM S 319", "COM S 336"],
    "jeremy-sheaffer": ["COM S 127", "COM S 227"],
    "wallapak-tavanapong": ["COM S 363", "COM S 461", "COM S 577"],
    "hongyang-gao": ["COM S 474", "COM S 573", "COM S 579"],
    "myra-cohen": ["COM S 417", "COM S 512"],
    "wei-le": ["COM S 342", "COM S 440"],
    "ali-jannesari": ["COM S 425", "COM S 583"],
    "mengdi-huai": ["COM S 472", "COM S 573"],
    "qi-li": ["COM S 481", "COM S 577"],
    "bowen-weng": ["COM S 472", "COM S 572"],
}


async def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Scrape ISU CS courses")
    parser.add_argument("--output", type=str, default="./data/courses.json", help="Output file")
    parser.add_argument("--use-known", action="store_true", help="Use pre-defined course data")
    
    args = parser.parse_args()
    
    if args.use_known:
        # Use pre-defined data
        data = {
            "courses": KNOWN_COURSES,
            "faculty_courses": KNOWN_FACULTY_COURSES,
            "scraped_at": datetime.now(timezone.utc).isoformat(),
            "source": "predefined"
        }
        
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        
        logger.info(f"Saved {len(KNOWN_COURSES)} pre-defined courses to {args.output}")
    else:
        # Scrape live data
        scraper = ISUCourseScraper()
        
        # Would need faculty list here for full scrape
        result = await scraper.scrape_all()
        
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        scraper.save(args.output)


if __name__ == "__main__":
    asyncio.run(main())
