import { useState, useEffect } from 'react'
import './App.css'

// ISU Colors
const ISU_RED = '#C8102E'
const ISU_GOLD = '#F1BE48'

// API Base URL
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function App() {
  const [activeTab, setActiveTab] = useState('search')
  const [query, setQuery] = useState('')
  const [searchResults, setSearchResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [faculty, setFaculty] = useState([])
  const [courses, setCourses] = useState([])
  const [stats, setStats] = useState(null)
  
  // People sidebar state
  const [showPhotos, setShowPhotos] = useState(true)
  const [facultyGroupBy, setFacultyGroupBy] = useState('group') // 'group', 'rank', 'none'
  const [facultyFilter, setFacultyFilter] = useState('all') // 'all', 'teaching', 'research'
  
  // Results view state
  const [resultsGroupBy, setResultsGroupBy] = useState('none') // 'none', 'type', 'date'
  
  // Load initial data
  useEffect(() => {
    fetchFaculty()
    fetchStats()
    fetchCourses()
  }, [])

  const fetchFaculty = async () => {
    try {
      const res = await fetch(`${API_URL}/api/faculty`)
      const data = await res.json()
      setFaculty(data)
    } catch (err) {
      console.error('Error fetching faculty:', err)
    }
  }

  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_URL}/api/stats`)
      const data = await res.json()
      setStats(data)
    } catch (err) {
      console.error('Error fetching stats:', err)
    }
  }

  const fetchCourses = async () => {
    try {
      const res = await fetch(`${API_URL}/api/courses`)
      const data = await res.json()
      setCourses(data.courses || [])
    } catch (err) {
      console.error('Error fetching courses:', err)
    }
  }

  const handleSearch = async (e) => {
    e.preventDefault()
    if (!query.trim()) return

    setLoading(true)
    try {
      const res = await fetch(`${API_URL}/api/search`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, limit: 20 })
      })
      const data = await res.json()
      setSearchResults(data)
    } catch (err) {
      console.error('Search error:', err)
    } finally {
      setLoading(false)
    }
  }

  // Group faculty by category
  const groupFaculty = (facultyList) => {
    if (facultyGroupBy === 'none') {
      return { 'All Faculty': facultyList }
    }
    
    const groups = {}
    facultyList.forEach(f => {
      const key = facultyGroupBy === 'group' 
        ? (f.group || 'Other')
        : (f.rank || 'Other')
      
      if (!groups[key]) groups[key] = []
      groups[key].push(f)
    })
    return groups
  }

  // Filter faculty
  const getFilteredFaculty = () => {
    let filtered = faculty
    if (facultyFilter === 'teaching') {
      filtered = faculty.filter(f => f.is_teaching_faculty)
    } else if (facultyFilter === 'research') {
      filtered = faculty.filter(f => !f.is_teaching_faculty)
    }
    return filtered
  }

  // Group results by type
  const groupResults = (results) => {
    if (!results || resultsGroupBy === 'none') return null
    
    const groups = {}
    results.forEach(r => {
      let key = 'Other'
      const type = (r.type || '').toLowerCase()
      
      if (type.includes('thesis')) key = 'Thesis'
      else if (type.includes('dissertation')) key = 'Dissertation'
      else if (type.includes('creative')) key = 'Creative Component'
      else if (type.includes('presentation')) key = 'Presentation'
      else if (type.includes('article')) key = 'Article'
      else if (type.includes('report')) key = 'Report'
      else if (type.includes('conference')) key = 'Conference Paper'
      
      if (!groups[key]) groups[key] = []
      groups[key].push(r)
    })
    return groups
  }

  // Render search results
  const renderSearchResults = () => {
    if (!searchResults) return null
    
    const grouped = groupResults(searchResults.sources)
    
    return (
      <div className="search-results">
        {/* AI Answer */}
        <div className="ai-answer">
          <h3>🤖 AI Answer</h3>
          <div className="answer-content">
            {searchResults.answer}
          </div>
          {searchResults.files_searched > 0 && (
            <div className="search-meta">
              Searched {searchResults.files_searched} indexed documents • Mode: {searchResults.search_mode}
            </div>
          )}
        </div>

        {/* Results grouping toggle */}
        <div className="results-controls">
          <label>Group by: </label>
          <select value={resultsGroupBy} onChange={e => setResultsGroupBy(e.target.value)}>
            <option value="none">None (List)</option>
            <option value="type">Document Type</option>
          </select>
        </div>

        {/* Sources */}
        <div className="sources">
          <h3>📚 Related Publications ({searchResults.sources?.length || 0})</h3>
          
          {resultsGroupBy === 'type' && grouped ? (
            // Tree view grouped by type
            <div className="results-tree">
              {Object.entries(grouped).map(([type, items]) => (
                <details key={type} open>
                  <summary className="type-header">
                    {getTypeIcon(type)} {type} ({items.length})
                  </summary>
                  <ul className="type-items">
                    {items.map((source, idx) => (
                      <li key={idx} className="source-item">
                        <a href={source.url} target="_blank" rel="noopener noreferrer">
                          {source.title}
                        </a>
                        <div className="source-meta">
                          {source.authors?.slice(0, 2).join(', ')} • {source.date}
                        </div>
                      </li>
                    ))}
                  </ul>
                </details>
              ))}
            </div>
          ) : (
            // Flat list view
            <ul className="sources-list">
              {searchResults.sources?.map((source, idx) => (
                <li key={idx} className="source-item">
                  <a href={source.url} target="_blank" rel="noopener noreferrer">
                    {source.title}
                  </a>
                  <div className="source-meta">
                    {source.authors?.slice(0, 2).join(', ')} • {source.date} • {source.type}
                  </div>
                  {source.abstract && (
                    <p className="source-abstract">{source.abstract}</p>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Suggested queries */}
        {searchResults.suggested_queries?.length > 0 && (
          <div className="suggestions">
            <h4>Related Searches:</h4>
            {searchResults.suggested_queries.map((q, idx) => (
              <button 
                key={idx} 
                className="suggestion-btn"
                onClick={() => { setQuery(q); }}
              >
                {q}
              </button>
            ))}
          </div>
        )}
      </div>
    )
  }

  // Get icon for document type
  const getTypeIcon = (type) => {
    const icons = {
      'Thesis': '📜',
      'Dissertation': '🎓',
      'Creative Component': '💡',
      'Presentation': '📊',
      'Article': '📄',
      'Report': '📋',
      'Conference Paper': '🎤',
      'Other': '📁'
    }
    return icons[type] || '📄'
  }

  // Render people sidebar
  const renderPeopleSidebar = () => {
    const filteredFaculty = getFilteredFaculty()
    const groupedFaculty = groupFaculty(filteredFaculty)

    return (
      <aside className="people-sidebar">
        <h3>👥 Faculty</h3>
        
        {/* Controls */}
        <div className="sidebar-controls">
          <label>
            <input 
              type="checkbox" 
              checked={showPhotos} 
              onChange={e => setShowPhotos(e.target.checked)} 
            />
            Show Photos
          </label>
          
          <select value={facultyFilter} onChange={e => setFacultyFilter(e.target.value)}>
            <option value="all">All Faculty</option>
            <option value="teaching">Teaching Faculty</option>
            <option value="research">Research Faculty</option>
          </select>
          
          <select value={facultyGroupBy} onChange={e => setFacultyGroupBy(e.target.value)}>
            <option value="group">Group by Area</option>
            <option value="rank">Group by Rank</option>
            <option value="none">No Grouping</option>
          </select>
        </div>

        {/* Faculty list */}
        <div className="faculty-list">
          {Object.entries(groupedFaculty).map(([group, members]) => (
            <div key={group} className="faculty-group">
              {facultyGroupBy !== 'none' && (
                <h4 className="group-header">{group} ({members.length})</h4>
              )}
              <ul>
                {members.map(f => (
                  <li key={f.id} className="faculty-item">
                    {showPhotos && f.photo_url && (
                      <img 
                        src={f.photo_url} 
                        alt={f.name}
                        className="faculty-photo"
                        onError={e => e.target.style.display = 'none'}
                      />
                    )}
                    <div className="faculty-info">
                      <a href={f.profile_url} target="_blank" rel="noopener noreferrer">
                        {f.name}
                      </a>
                      <span className="faculty-rank">{f.rank}</span>
                      {f.courses_taught?.length > 0 && (
                        <span className="faculty-courses">
                          Teaches: {f.courses_taught.slice(0, 3).join(', ')}
                          {f.courses_taught.length > 3 && '...'}
                        </span>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </aside>
    )
  }

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-content">
          <h1>🔬 ISU Research Search</h1>
          <p>AI-Powered Search for Iowa State Computer Science</p>
        </div>
        <nav className="nav">
          <button 
            className={activeTab === 'search' ? 'active' : ''} 
            onClick={() => setActiveTab('search')}
          >
            🔍 Search
          </button>
          <button 
            className={activeTab === 'faculty' ? 'active' : ''} 
            onClick={() => setActiveTab('faculty')}
          >
            👥 Faculty
          </button>
          <button 
            className={activeTab === 'courses' ? 'active' : ''} 
            onClick={() => setActiveTab('courses')}
          >
            📚 Courses
          </button>
          <button 
            className={activeTab === 'topics' ? 'active' : ''} 
            onClick={() => setActiveTab('topics')}
          >
            🗺️ Topic Map
          </button>
        </nav>
      </header>

      {/* Main content with sidebar */}
      <div className="main-container">
        {/* Main content area */}
        <main className="main-content">
          {activeTab === 'search' && (
            <div className="search-page">
              <form onSubmit={handleSearch} className="search-form">
                <input
                  type="text"
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  placeholder="Search research papers, topics, faculty..."
                  className="search-input"
                />
                <button type="submit" disabled={loading} className="search-btn">
                  {loading ? '⏳ Searching...' : '🔍 Search'}
                </button>
              </form>

              {/* Stats */}
              {stats && (
                <div className="stats-bar">
                  <span>📊 {stats.indexed_documents} documents indexed</span>
                  <span>👥 {stats.faculty_count} faculty</span>
                  <span>{stats.gemini_enabled ? '✅ AI Enabled' : '⚠️ AI Disabled'}</span>
                </div>
              )}

              {renderSearchResults()}
            </div>
          )}

          {activeTab === 'faculty' && (
            <div className="faculty-page">
              <h2>Computer Science Faculty</h2>
              <div className="faculty-grid">
                {faculty.map(f => (
                  <div key={f.id} className="faculty-card">
                    {f.photo_url && (
                      <img src={f.photo_url} alt={f.name} className="card-photo" />
                    )}
                    <h3>{f.name}</h3>
                    <p className="rank">{f.rank}</p>
                    {f.title && <p className="title">{f.title}</p>}
                    <div className="interests">
                      {f.research_interests?.slice(0, 3).map((interest, idx) => (
                        <span key={idx} className="interest-tag">{interest}</span>
                      ))}
                    </div>
                    {f.courses_taught?.length > 0 && (
                      <div className="courses">
                        <strong>Courses:</strong> {f.courses_taught.join(', ')}
                      </div>
                    )}
                    <a href={f.profile_url} target="_blank" rel="noopener noreferrer" className="profile-link">
                      View Profile →
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'courses' && (
            <div className="courses-page">
              <h2>Computer Science Courses</h2>
              <div className="courses-grid">
                {courses.length > 0 ? courses.map(course => (
                  <div key={course.number} className="course-card">
                    <h3>{course.number}</h3>
                    <p className="course-name">{course.name}</p>
                    <span className="level-tag">{course.level}</span>
                    {course.topics?.map((topic, idx) => (
                      <span key={idx} className="topic-tag">{topic}</span>
                    ))}
                  </div>
                )) : (
                  <p>Loading courses...</p>
                )}
              </div>
            </div>
          )}

          {activeTab === 'topics' && (
            <div className="topics-page">
              <h2>Research Topic Map</h2>
              <iframe 
                src="/topic-map.html" 
                title="Topic Map"
                className="topic-iframe"
              />
            </div>
          )}
        </main>

        {/* People sidebar - show on search tab */}
        {activeTab === 'search' && renderPeopleSidebar()}
      </div>

      {/* Footer */}
      <footer className="footer">
        <p>© {new Date().getFullYear()} Iowa State University • Computer Science Department</p>
        <p>Powered by Gemini AI • Data from ISU DSpace Repository</p>
      </footer>
    </div>
  )
}

export default App
